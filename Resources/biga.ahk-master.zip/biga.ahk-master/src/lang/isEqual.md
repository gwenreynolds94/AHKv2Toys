Performs a deep comparison between two values to determine if they are equivalent.

This method supports comparing strings and objects.


## Arguments
value (*): The value to compare.

other (...*): The other value to compare.


## Returns
(boolean): Returns true if the values are equivalent, else false.
