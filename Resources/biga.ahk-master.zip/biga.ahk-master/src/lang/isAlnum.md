Checks if value is an alnum.


## Arguments
value (*): The value to check.


## Returns
(boolean): Returns true if value is an alnum, else false.
