Checks if value is greater than other.


## Arguments
value (*): The value to compare.

other (*): The other value to compare.


## Returns
(boolean): Returns true if value is greater than other, else false.
