Converts value to an array.


## Arguments
value (*): The value to convert.


## Returns
(Array): Returns the converted array.
