This method returns a string indicating the type of `value`.


## Arguments
value (*): the value to check.


## Returns
(string): Returns value's type.
