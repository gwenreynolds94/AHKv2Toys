Checks if value is greater than or equal to other.


## Arguments
value (*): The value to compare.

other (*): The other value to compare.


## Returns
(boolean): Returns true if value is greater than or equal to other, else false.
