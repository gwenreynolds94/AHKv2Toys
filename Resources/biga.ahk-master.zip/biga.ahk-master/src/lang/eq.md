Performs a shallow comparison between two values to determine if they are equivalent.


## Arguments
value (*): The value to compare.

other (*): The other value to compare.


## Returns
(boolean): Returns true if the values are equivalent, else false.
