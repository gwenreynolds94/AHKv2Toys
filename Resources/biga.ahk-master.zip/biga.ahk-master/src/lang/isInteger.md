Checks if value is an integer.


## Arguments
value (*): The value to check.


## Returns
(boolean): Returns true if value is an integer, else false.
