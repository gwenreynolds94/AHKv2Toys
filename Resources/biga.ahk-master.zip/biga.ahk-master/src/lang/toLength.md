Converts value to an integer suitable for use as the length of an array-like object.


## Arguments
value (*): The value to convert.


## Returns
(number): Returns the converted integer.
