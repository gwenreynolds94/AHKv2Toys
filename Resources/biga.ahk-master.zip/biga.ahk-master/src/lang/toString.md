Converts value to a string. An empty string is returned for undefined values. The sign of `-0` is preserved.


## Arguments
value (*): The value to convert.


## Returns
(boolean): Returns the converted string.
