Checks if value is an exception error object.


## Arguments
value (*): The value to check.


## Returns
(boolean): Returns true if value is an exception object, else false.
