Checks if value is less than other.


## Arguments
value (*): The value to compare.

other (*): The other value to compare.


## Returns
(boolean): Returns true if value is less than other, else false.
