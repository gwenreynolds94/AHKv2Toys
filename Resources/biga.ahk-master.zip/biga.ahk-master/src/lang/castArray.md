Casts value as an array if it's not one.

## Arguments
value (*): The value to inspect.


## Returns
(Array): Returns the cast array.
