Checks if object conforms to source by invoking the predicate properties of source with the corresponding property values of object.


## Arguments
object (Object): The object to inspect.

source (Object): The object of property predicates to conform to.


## Returns
(boolean): Returns true if object conforms, else false.
