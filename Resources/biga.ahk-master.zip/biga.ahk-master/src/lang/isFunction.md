Checks if `value` is callable as a function object, bound function, or object method.


## Arguments
value (*): The `value` to check.


## Returns
(boolean): Returns `true` if `value` is callable, else `false`.
