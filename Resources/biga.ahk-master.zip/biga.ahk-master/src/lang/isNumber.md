Checks if value is a number.


## Arguments
value (*): The value to check.


## Returns
(boolean): Returns true if value is a number, else false.
