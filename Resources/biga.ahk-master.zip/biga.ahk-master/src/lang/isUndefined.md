Checks if value is undefined or blank.


## Arguments
value (*): The value to check.


## Returns
(boolean): Returns true if value is undefined, else false.
