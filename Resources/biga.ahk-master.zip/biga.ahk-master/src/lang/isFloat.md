Checks if value is a float.


## Arguments
value (*): The value to check.


## Returns
(boolean): Returns true if value is a float, else false.
