The opposite of [A.property](/?id=property); this method creates a function that returns the value at a given path of object.


## Arguments
object (Object): The object to query.


## Returns
(Function): Returns the new accessor function.
