This method returns the first argument it receives.

## Arguments
value (*): Any value.


## Returns
(*): Returns value.