This method returns a new empty array.


## Returns
(Array): Returns the new empty array.
