Creates a function that returns value.


## Arguments
value (*): The value to return from the new function.


## Returns
(Function): Returns the new constant function.
