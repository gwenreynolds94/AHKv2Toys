Generates a unique ID. If `prefix` is given, the ID is appended to it.


## Arguments
[prefix:=""] (string): The value to prefix the ID with.


## Returns
(string): Returns the unique ID.