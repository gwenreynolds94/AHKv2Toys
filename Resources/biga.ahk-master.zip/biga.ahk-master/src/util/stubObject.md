This method returns a new empty object.


## Returns
(Object): Returns the new empty object.
