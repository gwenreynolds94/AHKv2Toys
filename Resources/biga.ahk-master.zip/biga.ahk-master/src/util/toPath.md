Converts `value` to a property path array.


## Arguments
value (*): The value to convert.


## Returns
(Array): Returns the new property path array.
