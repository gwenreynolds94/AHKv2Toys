This method returns an empty string.


## Returns
(string): Returns the empty string.
