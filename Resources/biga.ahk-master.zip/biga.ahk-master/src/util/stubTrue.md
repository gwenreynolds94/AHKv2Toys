This method returns `true`.


## Returns
(boolean): Returns `true`.
