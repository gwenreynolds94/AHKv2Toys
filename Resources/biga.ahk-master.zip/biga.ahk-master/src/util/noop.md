This method returns AutoHotkey's closest undefined equivilant; `""`.
