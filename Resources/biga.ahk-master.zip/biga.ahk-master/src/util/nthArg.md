Creates a function that gets the argument at index n. If n is negative, the nth argument from the end is returned.


## Arguments
[n:=1] (number): The index of the argument to return.


## Returns
(Function): Returns the new pass-thru function.
