This method returns `false`.


## Returns
(boolean): Returns `false`.
