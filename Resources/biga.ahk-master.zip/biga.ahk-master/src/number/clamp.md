Clamps number within the inclusive lower and upper bounds.


## Arguments
number (number): The number to clamp.

lower (number): The lower bound.

upper (number): The upper bound.


## Returns
(number): Returns the clamped number.
