Creates an array of values corresponding to paths of object.

## Arguments
object (Object): The object to iterate over.

[paths] (...(string|string[])): The property paths to pick.


## Returns
(Array): Returns the picked values.
