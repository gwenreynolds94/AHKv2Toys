Creates an array of own enumerable string keyed-value pairs for object which can be consumed by A.fromPairs.


## Aliases
`.entries`


## Arguments
object (Object): The object to query.


## Returns
(Array): Returns the key-value pairs.
