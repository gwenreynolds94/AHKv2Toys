Creates an array of the own enumerable properties of object.


## Arguments
object (Object): The object to query.


## Returns
(Array): Returns the array of property names.
