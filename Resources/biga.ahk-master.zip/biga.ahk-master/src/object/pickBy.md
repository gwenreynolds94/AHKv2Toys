Creates an object composed of the object properties predicate returns truthy for. The predicate is invoked with two arguments: (value, key).


## Arguments
object (Object): The source object.

[predicate:=.identity] (Function): The function invoked per property.


## Returns
(Object): Returns the new object.
