This method is like [A.find](/?id=find) except that it returns the key of the first element predicate returns truthy for instead of the element itself.


## Arguments
collection (Array|Object): The collection to inspect.

function (Function): The function invoked per iteration.

[fromIndex:=1] (number): The index to search from.


## Returns
(*): Returns the matched element, else false.
