Creates an object composed of the picked object properties.


## Arguments
object (Object): The source object.

[paths] (...(string|string[])): The property paths to pick.

## Returns
(Object): Returns the new object.
