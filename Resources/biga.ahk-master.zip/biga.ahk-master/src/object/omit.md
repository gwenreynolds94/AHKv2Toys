The opposite of [A.pick](/?id=pick); this method creates an object composed of the own and inherited enumerable property paths of object that are not omitted.


## Arguments
object (Object): The source object.

[paths] (...(string|string[])): The property paths to omit.

## Returns
(Object): Returns the new object.
