Removes trailing whitespace or specified characters from string.


## Arguments
[string:=""] (string): The string to trim.

[chars:=whitespace] (string): The characters to trim.


## Returns
(string): Returns the trimmed string.
