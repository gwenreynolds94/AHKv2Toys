Converts string, as space separated words, to lower case.


## Arguments
[string:=""] (string): The string to convert.


## Returns
(string): Returns the lower cased string.
