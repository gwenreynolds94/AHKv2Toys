Repeats the given string `n` times.


## Arguments
[string:=""] (string): The string to repeat.

[n:=1] (number): The number of times to repeat the string.

## Returns

(string): Returns the repeated string.
