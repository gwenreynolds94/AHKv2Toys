Converts string to an integer.

> [!Warning]
> This method has not reached pairity with Lodash.
> missing the radix to interpret value by parameter

## Arguments
string (string): The string to convert.

<!-- [radix:=10] (number): The radix to interpret value by. -->


## Returns

(number): Returns the converted integer.
