Splits string into an array of its words.


## Arguments
string:="" (string): The string to inspect.

[pattern] (RegExp|string): The pattern to match words.


## Returns

(Array): Returns the words of string.
