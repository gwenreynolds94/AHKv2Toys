Pads string on the right side if it's shorter than length. Padding characters are truncated if they exceed length.

## Arguments
[string:=""] (string): The string to pad.

[length:=0] (number): The padding length.

[chars:=" "] (string): The string used as padding.


## Returns
(string): Returns the padded string.
