Converts the first character of string to upper case.


## Arguments
[string:=""] (string): The string to convert.


## Returns
(string): Returns the converted string.
