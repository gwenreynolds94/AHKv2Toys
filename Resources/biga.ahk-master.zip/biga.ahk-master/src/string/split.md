Splits string by separator.


## Arguments
[string:=""] (string): The string to split.

[separator:=","] (RegExp|string): The separator pattern to split by.

[limit:=0] (number): The length to truncate results to.

## Returns
(Array): Returns the string segments.
