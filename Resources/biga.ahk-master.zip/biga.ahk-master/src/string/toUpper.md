Converts string, as a whole, to upper case


## Arguments
string (string): The string to convert.


## Returns
(string): Returns the upper cased string.