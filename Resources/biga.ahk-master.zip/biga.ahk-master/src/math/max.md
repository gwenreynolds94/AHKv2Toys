Computes the maximum value of array. If array is empty or falsey, `""` is returned.


## Arguments
array (Array): The array to iterate over.


## Returns
(*): Returns the maximum value.
