Subtract two numbers.


## Arguments
minuend (number): The first number in a subtraction.

subtrahend (number): The second number in a subtraction.


## Returns
(number): Returns the difference.
