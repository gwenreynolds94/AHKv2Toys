Computes number rounded down to precision.


## Arguments
number (number): The number to round down.

[precision:=0] (number): The precision to round down to.


## Returns
(number): Returns the rounded down number.