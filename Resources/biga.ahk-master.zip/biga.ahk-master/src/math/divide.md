Divide two numbers.


## Arguments
dividend (number): The first number in a division.

divisor (number): The second number in a division.


## Returns
(number): Returns the quotient.
