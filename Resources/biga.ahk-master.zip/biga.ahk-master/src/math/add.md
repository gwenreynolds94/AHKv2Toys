Adds two numbers.


## Arguments
augend (number): The first number in an addition.

addend (number): The second number in an addition.


## Returns
(number): Returns the total.
