Computes the sum of the values in array.


## Arguments
array (Array): The array to iterate over.


## Returns
(number): Returns the sum.
