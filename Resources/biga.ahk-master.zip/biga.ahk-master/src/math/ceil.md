Computes number rounded up to precision.


## Arguments
number (number): The number to round up.

[precision:=0] (number): The precision to round up to.


## Returns
(number): Returns the rounded up number.
