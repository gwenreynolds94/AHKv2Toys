Creates an array of grouped elements, the first of which contains the first elements of the given arrays, the second of which contains the second elements of the given arrays, and so on.

> [!Warning]
> This method has not reached pairity with Lodash.
> Output will not match Lodash output in the event the length of all supplied arrays are not the same.

## Arguments
[arrays*] (...Array): The arrays to process.


## Returns

(Array): Returns the new array of grouped elements.