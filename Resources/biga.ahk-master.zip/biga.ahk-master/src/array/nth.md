Gets the element at index n of array. If n is negative, the nth element from the end is returned.


## Arguments
array (Array): The array to query.

[n:=1] (number): The index of the element to return.


## Returns
(*): Returns the nth element of array.
