The inverse of A.toPairs; this method returns an object composed from key-value pairs.

## Arguments
pairs (Array): The key-value pairs.


## Returns
(Object): Returns the new object.
