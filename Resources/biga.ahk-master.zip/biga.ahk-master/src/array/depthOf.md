This method is explores the array and returns the maximum depth.


## Arguments
array (Array): The array to inspect.


## Returns
(number): Returns the maximum depth.
