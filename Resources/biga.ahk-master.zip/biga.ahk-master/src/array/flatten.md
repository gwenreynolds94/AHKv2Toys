Flattens array a single level deep.


## Arguments
array (Array): The array to flatten.


## Returns
(Array): Returns the new flattened array.
