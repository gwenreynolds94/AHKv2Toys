Gets all but the last element of array.


## Arguments
array (Array): The array to query.

## Returns
(Array): Returns the slice of array.
