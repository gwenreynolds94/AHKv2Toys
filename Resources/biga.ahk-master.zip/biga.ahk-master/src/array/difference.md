Creates an array of array values not included in the other given arrays. The order of result values are determined by the first array.

## Arguments
array (Array): The array to inspect.

values (...Array): The values to exclude.


## Returns
(Array): Returns the new array of filtered values.
