Creates a slice of array from start up to end.


## Arguments
array (Array): The array to slice.

[start:=1] (number): The start position.

[end:=array.Count()] (number): The end position.


## Returns
(Array): Returns the slice of array.
