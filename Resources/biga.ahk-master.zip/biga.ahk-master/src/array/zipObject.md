This method is like [A.fromPairs](/?id=frompairs) except that it accepts two arrays, one of property identifiers and one of corresponding values.


## Arguments
[props:=[]] (Array): The property identifiers.

[values:=[]] (Array): The property values.


## Returns

(Object): Returns the new object.
