Reverses array so that the first element becomes the last, the second element becomes the second to last, and so on.


## Arguments
array (Array): The array to modify.


## Returns
(Array): Returns array.
