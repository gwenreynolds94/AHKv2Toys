This method is like [A.uniq](/?id=uniq) except that it's optimized for sorted arrays.


## Arguments
array (Array): The sorted array to inspect.


## Returns
(array): Returns the new duplicate free array.
