This method is like [A.indexOf](/?id=indexof) except that it iterates over elements of array from right to left.


## Arguments
array (Array): The array to inspect.

value (*): The value to search for.

[fromIndex:=array.Count()] (number): The index to search from.


## Returns
(number): Returns the index of the matched value, else -1.
