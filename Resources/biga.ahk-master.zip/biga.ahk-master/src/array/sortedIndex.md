Uses a search to determine the lowest index at which value should be inserted into array in order to maintain its sort order.


## Arguments
array (Array): The sorted array to inspect.

value (*): The value to evaluate.


## Returns
(number): Returns the index at which value should be inserted into array.
