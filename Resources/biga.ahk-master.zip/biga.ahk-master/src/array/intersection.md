Creates an array of unique values that are included in all given arrays. The order of result values are determined by the first array.


## Arguments
[arrays*] (...Array): The arrays to inspect.


## Returns
(Array): Returns the new array of intersecting values.
