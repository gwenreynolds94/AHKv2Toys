Recursively flattens array.


## Arguments
array (Array): The array to flatten.


## Returns
(Array): Returns the new flattened array.
