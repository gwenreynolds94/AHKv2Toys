Creates an array with all falsey values removed. The values false, 0, and "" are falsey.


## Arguments
array (Array): The array to compact.


## Returns
(Array): Returns the new array of filtered values.
