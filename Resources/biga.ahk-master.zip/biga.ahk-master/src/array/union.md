Creates an array of unique values, in order, from all given arrays.


## Arguments
[arrays] (...Array): The arrays to inspect.


## Returns
(Array): Returns the new array of combined values.
