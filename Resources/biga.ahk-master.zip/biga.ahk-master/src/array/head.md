Gets the first element of array.

## Aliases
`.first`

## Arguments
array (Array): The array to query.


## Returns
(*): Returns the first element of array.
