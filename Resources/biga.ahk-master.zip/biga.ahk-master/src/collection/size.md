Gets the size of collection by returning its length for array-like values or the number of own enumerable string keyed properties for objects.


## Arguments
collection (Array|Object|string): The collection to inspect.


## Returns
(number): Returns the collection size.
