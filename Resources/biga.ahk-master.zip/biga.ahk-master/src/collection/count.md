Gets the number of occurrences of value if found in collection, else `0`

## Arguments
collection (Array|Object|string): The collection to inspect.

value (*): The value to count

[fromIndex:=1] (number): The index to search from

## Returns
(number): Returns the number of occurances.
