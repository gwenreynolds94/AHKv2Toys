This method is like [A.find](/?id=find) except that it iterates over elements of collection from right to left.


## Arguments
collection (Array|Object): The collection to inspect.

function (Function): The function invoked per iteration.


## Returns
(*): Returns the matched element, else false.
