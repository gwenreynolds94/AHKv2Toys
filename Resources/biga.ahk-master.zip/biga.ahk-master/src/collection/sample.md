Gets a single random element from collection.

## Arguments
collection (Array|Object|String): The collection to sample.


## Returns
(*): Returns the random element.


## Example
```autohotkey
A.sample([1, 2, 3, 4])
; => 2
```
