Iterates over elements of collection, returning the first element predicate returns truthy for.


## Arguments
collection (Array|Object): The collection to inspect.

function (Function): The function invoked per iteration.

[fromIndex:=1] (number): The index to search from.


## Returns
(*): Returns the matched element, else false.
