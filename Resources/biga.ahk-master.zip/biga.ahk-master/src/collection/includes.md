Checks if value is in collection. If collection is a string, it's checked for a substring of value.


## Arguments
collection (Array|Object|string): The collection to inspect.

value (*): The value to search for.

[fromIndex:=1] (number): The index to search from.


## Returns
(boolean): Returns true if value is found, else false.
