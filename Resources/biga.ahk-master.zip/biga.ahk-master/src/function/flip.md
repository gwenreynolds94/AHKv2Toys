Creates a function that invokes func with arguments reversed.


## Arguments
func (Function): The function to flip arguments for.


## Returns
(Function): Returns the new flipped function.
