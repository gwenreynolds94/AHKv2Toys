### What is biga.ahk?

biga.ahk makes AutoHotkey easier by taking the hassle out of working with arrays, objects, strings, etc. It can be used to make quick work of normally tedious data manipulation.


<br><br>
Released under the [MIT license](https://opensource.org/licenses/MIT).
